// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

#include <stdexcept> // Necessary for std::runtime_error

bool do_even_more_custom_application_logic();

bool do_even_more_custom_application_logic() {
    throw std::runtime_error("Failure in even more custom logic");
    // Unreachable code removed
    return true; // This code is now unreachable
}


// Custom exception class, derived from std::runtime_error
class CustomApplicationException : public std::runtime_error {
public:
    using std::runtime_error::runtime_error; // Inheriting constructor for easy message passing
};

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // Try-catch block to handle potential exceptions from called functions
    try {
        if(do_even_more_custom_application_logic()) {
            // This line won't be executed because the called function always throws
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    } catch (const std::exception& e) {
        // Handling any exception derived from std::exception
        std::cerr << "Caught an exception: " << e.what() << std::endl;
    }

    // Throwing a custom exception to demonstrate catching it in main
    throw CustomApplicationException("Custom application logic failure");

    // This line won't be executed due to the exception
    std::cout << "Leaving Custom Application Logic." << std::endl;
}


#include <stdexcept> // Necessary for std::invalid_argument

float divide(float num, float den)
{
    // Checking for divide by zero and throwing an exception if true
    if (den == 0) {
        throw std::invalid_argument("Division by zero");
    }
    return (num / den); // Performing division if denominator is not zero
}


void do_division() noexcept
{
float numerator = 10.0f;
float denominator = 0;

// Handling exceptions specifically from divide function
try {
auto result = divide(numerator, denominator);
// This line won't be executed due to the exception
std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
} catch (const std::invalid_argument& e) {
// Catching and handling divide by zero exception
std::cerr << "Caught an exception in division: " << e.what() << std::endl;
}
}


int main()
{
    try {
        std::cout << "Exceptions Tests!" << std::endl;
        do_division(); // May throw divide by zero exception
        do_custom_application_logic(); // May throw a custom exception
    } catch (const CustomApplicationException& e) {
        // Handling custom application exceptions specifically
        std::cerr << "Caught a custom application exception: " << e.what() << std::endl;
    } catch (const std::exception& e) {
        // Handling all standard exceptions
        std::cerr << "Caught a standard exception: " << e.what() << std::endl;
    } catch (...) {
        // Catch-all handler for any other unhandled exceptions
        std::cerr << "Caught an unhandled exception." << std::endl;
    }
}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu